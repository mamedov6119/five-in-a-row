/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fiveinarow;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author murad
 */
public class Game extends javax.swing.JFrame {
    
    private int queue = 0;
    private int width;
    private int height;
    private int index;
    private JButton Buttons[][];
    /**
     * Creates new form Game
     */
    


    public Game(int index) {
        initComponents();   
        if (index == 0) {
            this.width = 6;
            this.height = 6;
            this.index = 0;
        } else if (index == 1) {
            this.width = 10;
            this.height = 10;
            this.index = 1;
        } else if (index == 2) {
            this.width = 14;
            this.height = 14;
            this.index = 2;

        }
        
        System.out.println("Width: " + width + " Height: " + height);
        CreateButtons();
        
    }
    
    public void CreateButtons() {
        board.setLayout(new GridLayout(width, height));
        Buttons = new JButton[height][width];
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                Buttons[i][j] = new JButton();
                
                Buttons[i][j].addActionListener((e) -> {
//                    System.out.println(e);
                        ButtonAction(e);
                });
                board.add(Buttons[i][j]);
                
            }
        }
    }
    
    public void ButtonAction(ActionEvent e) {
        System.out.println(e);
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (e.getSource() == Buttons[i][j]) {
                    System.err.println(i + " " + j);
                    if (Buttons[i][j].getText() == "") {
                        Buttons[i][j].setText((queue == 0 ? "X" : "O"));
                        
                        queue = (queue == 0 ? 1 : 0);
                        player_x.setForeground((queue == 0 ? Color.GREEN : Color.BLACK));
                        player_o.setForeground((queue == 1 ? Color.GREEN : Color.BLACK));
                        
                        String end_game_status = status();
                        if (end_game_status != "") {
                            System.out.println(end_game_status);
                            JDialog s = new JDialog(this , "Game Over", true);
                            if (end_game_status == "X") {
                                s.add( new JLabel ("X won the game!"));
                            } else if (end_game_status == "O") {
                                s.add( new JLabel ("O won the game!"));
                            } else {
                                s.add( new JLabel ("ITS A TIE!"));
                            }
                            s.setSize(300, 150);
                            s.setLayout(new GridBagLayout());
                            s.setVisible(true);
                            this.setVisible(false);
                            new Game(this.index).setVisible(true);
                        }
                        
                    }
                }
            }
        }
    }
    
    private boolean won(int r, int dr, int c, int dc) {
        String s = Buttons[r][c].getText();
        for (int i = 1; i < 5; i++) {
            if (Buttons[r+dr*i][c+dc*i].getText() != s) return false;
        }   
        return true;  
    }
    
    private String fiveRowCol() {
        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width-4; j++) {
                if(Buttons[i][j].getText() == Buttons[i][j+1].getText() && Buttons[i][j+1].getText() == Buttons[i][j+2].getText() && Buttons[i][j+2].getText() == Buttons[i][j+3].getText() && Buttons[i][j+3].getText() == Buttons[i][j+4].getText()) {
                    return Buttons[i][j].getText();
                }
            }
        }
        return null;
    }
    
    
    public String status() {
        boolean endGame = true;
                for (int k = 0; k < height; k++) {
                    for (int b = 0; b < width; b++) {
                        if (Buttons[k][b].getText() == "") {
                            endGame = false;
                        }
                    }
                }
                
                if (endGame) {
                    System.out.println("END OF THE GAME!");
                    return "IT IS A TIE";
                    
                }

  
        if (fiveRowCol() != null) {
            return fiveRowCol();
        }
        
        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width; j++) {
                String w = Buttons[i][j].getText();
                
                if (w != "") {
                    if (i < this.height - 4) {
                        if (won(i,1,j,0)) {
                            return w;
                        }  
                    
                    if(j < width - 4) {
                        if(won(i,0,j,1)) {
                            return w;
                        } 
                        
                        if(i < this.height - 4){
                            if (won(i, 1, j, 1)) {
                                return w;
                            } 
                        }
                    }
                     }
                    if (j > 3 && i < this.height - 4) {
                        if(won(i, 1, j, -1)) {
                            return w;
                        }  
                    }
                    
                } 
           
        }
        }
     
                return "";
    }
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        player_x = new javax.swing.JLabel();
        player_o = new javax.swing.JLabel();
        board = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        player_x.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        player_x.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        player_x.setText("X turn");

        player_o.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        player_o.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        player_o.setText("O turn");

        board.setMaximumSize(new java.awt.Dimension(300, 300));
        board.setMinimumSize(new java.awt.Dimension(300, 300));
        board.setPreferredSize(new java.awt.Dimension(300, 300));
        java.awt.GridBagLayout boardLayout = new java.awt.GridBagLayout();
        boardLayout.columnWidths = new int[] {10};
        board.setLayout(boardLayout);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(board, javax.swing.GroupLayout.DEFAULT_SIZE, 388, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(player_x, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(player_o, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(player_x, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(player_o, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(board, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel board;
    private javax.swing.JLabel player_o;
    private javax.swing.JLabel player_x;
    // End of variables declaration//GEN-END:variables
}
